import { Todo } from "./models/todo";

let todos: Todo[] = [];

export function get(): Promise<Todo[]> {
  return new Promise((res, rej) => {
    setTimeout(() => {
      res(todos);
    }, 2000);
  });
}

export function add(task: string): Promise<Todo>{
  return new Promise((res, rej) => {
    setTimeout(() => {
      const newTodo: Todo = {
        title: task,
        id: todos.length + 1,
        completed: false
      };
      todos.push(newTodo);
      res(newTodo)
    }, 2000);
  })
}

export function aggiorna(todos: Todo, i:number): Promise<Todo>{
  return new Promise((res, rej)=>{
    setTimeout(() => {
      todos.completed = true;
      res(todos)
    }, 2000);
  })
}

export function deleteTodo(todo: Todo, i: number): Promise<void> {
  return aggiorna(todo, i).then(() => {
    todos.splice(i, 1);
  })
}

export function setTodoAsComplete(todo: Todo, i: number): Promise<void> {
  return aggiorna(todo, i).then(() => {
    todos[i].completed = true;
  });
}

