import { Component, OnInit } from '@angular/core';
import * as service from '../todos.service';
import { Todo } from '../models/todo';
@Component({
  template: `
    <ng-container *ngIf="todos; else elseTemplate">
      <div class="centrato">
        <ul>
          <li *ngFor="let item of todos; let i = index">
           ops non ci sono task!
          </li>
        </ul>
      </div>
    </ng-container>

    <ng-template #elseTemplate>
      <p class="center">Recupero task completati...</p>
    </ng-template>

  `,
  styles: [
    `
      .centrato {
        width: auto;
        heigth: auto;
        margin: 50px auto;
      }
    `,
  ],
})
export class CompletedPage {
  todos!: Todo[];
  constructor() {
    this.getTodo();

  }
  getTodo() {
    service.get().then((todos) => {
      this.todos = todos.filter((todo) => todo.completed);
      console.log(todos);
    });
  }
}

